<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apna Dhyan/Meditation</title>
    <link rel="shortcut icon" href="https://i.pinimg.com/736x/0d/cf/b5/0dcfb548989afdf22afff75e2a46a508.jpg" id="imm" type=" svg+xml">


    <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@500;800;900&amp;display=swap" rel="stylesheet">
</head>
<style>
    :root {
    --primary-color: lightsteelblue;
    --secondary-color: lightpink;
    --large: 200px;
    --small: 10px;
    --timing: 8s;
}

body {
    width: 100vw;
    height: 100vh;
    display: grid;
    overflow: hidden;
    justify-content: center;
    align-content: center;
}

main, section {
    height: 300px;
    width: 100vw;
    display: grid;
    justify-content: center;
    align-items: center;
}

section {
    height: auto;
}

div{
    background-color: var(--primary-color);
    width: var(--small);
    height: var(--small);
    border-radius: calc( var(--small) / 2);
    display: inline-block;
    animation: breath var(--timing) ease infinite none running
}

input {
    margin: 20px 0;
    height: 40px;
    font-size: 1.25em;
}

h1,p,input,label {
    color: #6E7B8B;
    font-family: "Work Sans", Arial, Helvetica, sans-serif;
    text-align: center;
}

@keyframes breath {
 25%, 50% {
    background-color: var(--secondary-color);
    width: var(--large);
    height: var(--large);
    border-radius: calc( var(--large) / 2);
 }  

}

#btn{
    position: relative;
    left: 19vh;
    width: 23%;
    border-radius: 80px;
    height: 87px;
    background-color: aliceblue;

} 

#btn:hover{
    background-color: cornflowerblue;
}
</style>
<body>
    <h1>focused breathing</h1>
    <main>
        <div></div>
    </main>
    <section>
        <p>breath in through the nose as the circle expands <br>
            hold, and release through the mouth as it contracts. <br> repeat as needed.</p> 
        <label for="number">adjust timing of animation in seconds</label>
        <input type="number" id="number" value="8" min="1">
     <a  href="/apna dhyan/"><button id="btn" >Go Back!</button></a>

    </section>
</body>
<script src="js/script.js"></script>
<script>
    const input = document.querySelector("input[type='number']")

document.querySelector("input[type='number']").addEventListener('change', (event) => {
    document.documentElement.style.setProperty('--timing', input.value + "s");
})
</script>
</html>