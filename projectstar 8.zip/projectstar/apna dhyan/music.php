<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apna Dhyan/music</title>
    <link rel="shortcut icon" href="https://i.pinimg.com/736x/0d/cf/b5/0dcfb548989afdf22afff75e2a46a508.jpg" id="imm" type=" svg+xml">


    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link href="css/music.css" rel="stylesheet">

</head>
<body>
    
<!-- header section starts  -->

<header class="header">
    
    <a href="index.html" class="logo"><img src="https://i.pinimg.com/736x/0d/cf/b5/0dcfb548989afdf22afff75e2a46a508.jpg" width= 60px></a>
    <nav class="navbar">
    <a href="/apna dhyan/">Dashboard</a>
        <a href="/index.php">Main-Dashboard</a>
    

    </nav>

    <div id="menu-btn" class="fas fa-bars"></div>
    

</header>

<!-- header section ends -->
<!-- title starts here -->
<div class="title">

  </div>
<!-- title ends here -->


<!-- quotes section starts  -->
<section class="quotes" >

    <div class="write">
        <h1>“ Music can have a profound effect on mood, including confidence level or how relaxed you are.” — <span class="black">
           <i>Corrina Thurston  </span></i><i class="fas fa-quote-right"></i>
        </h1>
    </div>
</section>
<!-- quotes section ends -->

<!-- music section starts here -->

  <section class="box2">
    <!-- <div class="title">
      <h1>Feel Good Music !</h1>
    </div> -->
   <div class="container">
   <iframe style="border-radius:12px" src="https://open.spotify.com/embed/playlist/1Vi7vReqfgQRoLrEsnR0KO?utm_source=generator" width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>
    <!-- <iframe src="https://open.spotify.com/embed/playlist/1FyynjLpkha9r2RSUPoRER?utm_source=generator" width="100%" height="380" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"></iframe> -->
   </div>
   <!-- https://open.spotify.com/playlist/1Vi7vReqfgQRoLrEsnR0KO?si=2c28581c206b4dfa -->
   
      
   <a href="/projectstar/apna dhyan/" ><button class="btn">Go Back</button></a>
  </section>
<!-- music section ends here -->


















<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>
