<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apna Dhyan</title>
    <link rel="shortcut icon" href="https://i.pinimg.com/736x/0d/cf/b5/0dcfb548989afdf22afff75e2a46a508.jpg" id="imm" type=" svg+xml">

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- custom css file link  -->
    <link href="css/happyspace.css" rel="stylesheet">

</head>

<style>
    #ii{
        border-radius: 208px;
    }
</style>


<body>
    
<!-- header section starts  -->

<header class="header">
    
    <a href="http://localhost/projectstar/apna%20dhyan/index.php" class="logo"><img src="https://i.pinimg.com/736x/0d/cf/b5/0dcfb548989afdf22afff75e2a46a508.jpg" width= 60px></a>

    <nav class="navbar">
        <a href="/apna dhyan/">Dashboard</a>
        <a href="/index.php">Main-Dashboard</a>
    
    </nav>

    <div id="menu-btn" class="fas fa-bars"></div>

</header>

<!-- header section ends -->

<!-- info section starts  -->

<section class="home" id="home">

    <div class="content">
        <h3>Apna Dhyan</h3>
        <p>You can Sing. You can Dance. You can Smile - a lot.</p>
    </div>

    <div class="image">
        <img id="ii" src="https://i.pinimg.com/736x/0d/cf/b5/0dcfb548989afdf22afff75e2a46a508.jpg" alt="">
    </div>

</section>

<!-- info section ends -->


<!-- quotes section starts  -->
<section class="quotes" >

    <div class="write">
        <h1>“One small crack does not mean that you are broken, it means that you were put to the test and you didn't fall apart.” —<span class="p-colour"> Linda Poindexter</span> </h1>
    </div>
</section>
<!-- quotes section ends -->


<!-- contact section starts  -->

<section class="space" id="space">

    <h1 class="heading"> Apna <span>Dhyan</span>  </h1>

    <div class="icons-container">
    <div class="icons">
            <a  href="/apna dhyan/breath.php"><img src="https://i.ytimg.com/vi/U9YKY7fdwyg/maxresdefault.jpg" alt="" ></a>
        </div>
        <div class="icons">
            <a  href="/qw/"><img src="images/quiz-img.png" alt="" ></a>
        </div>
        <div class="icons">
            <a  href="self-quiz.php"><img src="images/self-img.png" alt="" ></a>
        </div>
        <div class="icons">
            <a  href="music.php"><img src="images/music-img.png" alt="" ></a>
        </div>
        <div class="icons">
            <a  href="video.php"><img src="images/video-img.png" alt="" ></a>
        </div>
        <div class="icons">
            <a  href="facetoface.php"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHcAAAB3CAMAAAAO5y+4AAAA5FBMVEX///80qFP7vARChfQZZ9IYgDjqQzX7twAQoT//+/T1+vYVoUEgij/A0vszfvQse/PY69z+79T8wwA5fuwXYtg2rEV6ds/pNzfxPiC5ye309/wAXtAAWc8spk78zWh3v4fzlo/pLhr0oJoAfTrpOSnr9u6538NuvoLzmZr+6bjoKyr80Wb/+ej8y1D92ID945+Ex5RVtW6c0qmm1bGMzqf5k4XwLgDqtwpXm0HQ1fNzb83/9tXSsBE2hTOmox2VniJ0lCq0pxqGmiRgkCzBrBYol0cepzRFr2FIgNmCqORtmOAAU9XCb/UrAAACo0lEQVRoge3aa3vSMBTA8aSOstEpFa+bi6NlBRUvdKiMOdh0KF6+//ex49omp7Qm6Ykv8n+5F/yec5o9D08DITabzWaz/f8dyKXKvqrL5LT6r5XY9puWI1n/rTwbnj2TduvvpJfdDlx516m/l2XPXBXXceQ2HQaumlv/IDut4rwyiw4XrJr7UoINXBPucsn63Shq7Jx2zep1GwPK4u6OaQO3CtefM0oZy4U3S9brdmnCJnCct+TttDrd84Wa5BVPq89tDNYs3YenzbC63Ki3YWG3HbgVuD7bsqCbXbIud3Wi8t2Qm1aPO0irkCtMq8NNP1rYDUVW3fVjjhVc/khpcbuMZ3kXWLK6O6QCy7nQklXd/kdPULPuwafPz8ECp8zXZbjRhTgs544vn8JdfnlYHAxfTQ4hNuPef3APrin+k4tBbmtaq5lwrztG3JuExXdHkzsW3Z0tWWz3a20VrvutY8S93bCY7tVkyyK6szSL505rmbDcm44Jd8SzOG7mROG5Mx5FcVtTgEVwhUeL4o5uQbZy9wJmK3e9QzPuPoXh6l363ZALwhguBKO4lJpyBRjL5Y81mss9ZDw3CyO6GRjTTcOobup0IbsbGNtd7xrdXcH47hI24C4ecgm3+Qiu6ZcIekt1Bxe7Ry/24B7/8IoDPz6BVdwnOR9aphh4S4jgslMfghHc5ZWRAVd8643kksbprvfe1bmEnHPnHcvlrlPwXO5lP55Lojjn3qpiN/eermo3fXmF65Lh+s8erku63vLeeY7sQvfsKG5yuiidDwm6m4zsR8SEy1eNOyh0xzmsmjssdI9/VuFGhS45OtHullhz0i/4Ccu7LN75E6AUDMmyLmO9ElteNP69dyL0p8z3ZzHW2/GzI6FjoIZc/6DabDabzWauv57QlFxzw57cAAAAAElFTkSuQmCC" alt="" ></a>
        </div>
    </div>


</section>








<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>
