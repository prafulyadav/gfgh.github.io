<?php 
session_start();
include "connection.php";
if (isset($_SESSION['id'])) {
	
	if (isset($_GET['n']) && is_numeric($_GET['n'])) {
	        $qno = $_GET['n'];
	        if ($qno == 1) {
	        	$_SESSION['quiz'] = 1;
	        }
	        }
	        else {
	        	header('location: question.php?n='.$_SESSION['quiz']);
	        } 
	        if (isset($_SESSION['quiz']) && $_SESSION['quiz'] == $qno) {
			$query = "SELECT * FROM questions WHERE qno = '$qno'" ;
			$run = mysqli_query($conn , $query) or die(mysqli_error($conn));
			if (mysqli_num_rows($run) > 0) {
				$row = mysqli_fetch_array($run);
				$qno = $row['qno'];
                 $question = $row['question'];
                 $ans1 = $row['ans1'];
                 $ans2 = $row['ans2'];
                 $ans3 = $row['ans3'];
                 $ans4 = $row['ans4'];
                 $correct_answer = $row['correct_answer'];
                 $_SESSION['quiz'] = $qno;
                 $checkqsn = "SELECT * FROM questions" ;
                 $runcheck = mysqli_query($conn , $checkqsn) or die(mysqli_error($conn));
                 $countqsn = mysqli_num_rows($runcheck);
                 $time = time();
                 $_SESSION['start_time'] = $time;
                 $allowed_time = $countqsn * 0.05;
                 $_SESSION['time_up'] = $_SESSION['start_time'] + ($allowed_time * 60) ;
                 

			}
			else {
				echo "<script> alert('something went wrong');
			window.location.href = 'home.php'; </script> " ;
			}
		}
		else {
		echo "<script> alert('error');
			window.location.href = 'home.php'; </script> " ;
	}
?>
<?php 
$total = "SELECT * FROM questions ";
$run = mysqli_query($conn , $total) or die(mysqli_error($conn));
$totalqn = mysqli_num_rows($run);

?>




<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!--=============== FAVICON ===============-->
        <!-- <link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon"> -->

        <!--=============== BOXICONS ===============-->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">

        <!--=============== SWIPER CSS ===============--> 
        <link rel="stylesheet" href="assets/css/swiper-bundle.min.css">

        <!--=============== CSS ===============--> 
        <link rel="stylesheet" href="assets/css/styles.css">

        <link rel="shortcut icon" href="https://i.pinimg.com/736x/0d/cf/b5/0dcfb548989afdf22afff75e2a46a508.jpg" id="imm" type=" svg+xml">
	<title>SELFCAREBOOSTER</title>
    </head>
	<style>
		:root {
  --header-height: 3.5rem;

  /*========== Colors ==========*/
  --hue: 14;
  --first-color: hsl(var(--hue), 91%, 54%);
  --first-color-alt: hsl(var(--hue), 91%, 50%);
  --title-color: hsl(var(--hue), 4%, 100%);
  --text-color: hsl(var(--hue), 4%, 85%);
  --text-color-light: hsl(var(--hue), 4%, 55%);

  /* gradient*/
  --body-color: linear-gradient(90deg, hsl(197, 83%, 51%) 0%, hsl(211, 86%, 62%) 100%);
  --container-color: linear-gradient(136deg, hsl(191, 100%, 50%) 0%, hsl(192, 100%, 52%) 100%);
  

		}
	</style>
    <body>
   
            <section class="section discount">
                <div class="discount__container container grid">
                    <div class="discount__data">
                        <h2 class="discount__title">Question <?php echo $qno; ?> of <?php echo $totalqn; ?></h2>
                        <p class="question"><?php echo $question; ?></p>

                        <form method="post" action="process.php">
                            <ul class="choices">
								<br>
                               <li><input name="choice" type="radio" value="a" required=""><?php echo $ans1; ?></li>
							   <br>
                               <li><input name="choice" type="radio" value="b" required=""><?php echo $ans2; ?></li>
							   <br>
                               <li><input name="choice" type="radio" value="c" required=""><?php echo $ans3; ?></li>
							   <br>
                               <li><input name="choice" type="radio" value="d" required=""><?php echo $ans4; ?></li>
							   <br>
                             
                            </ul>
                           
                            <input type="submit" class="button" value="Submit"> 
                            <input type="hidden" name="number" value="<?php echo $qno;?>">
                            <br>
                            <br>
                            <a href="results.php" class="button">Stop Quiz</a>
                     
                        </form>
                    </div>


                    
                    
                       
                 

                    <!-- <img src="assets/img/discount-img.png" alt="" class="discount__img"> -->
                </div>
            </section>

        
        
        <!--=============== SCROLL REVEAL ===============-->
        <script src="assets/js/scrollreveal.min.js"></script>

        <!--=============== SWIPER JS ===============-->
        <script src="assets/js/swiper-bundle.min.js"></script>
        
        <!--=============== MAIN JS ===============-->
        <script src="assets/js/main.js"></script>
    </body>
</html>


<?php } 
else {
	header("location: home.php");
}
?>