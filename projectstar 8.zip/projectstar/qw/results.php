<?php 
// /Applications/XAMPP/xamppfiles/htdocs/projectstar/qw/index.php
session_start();
include "connection.php";
if (isset($_SESSION['id'])) {
	?>
	<?php if(!isset($_SESSION['score'])) {
		header("location: question.php?n=1");
	}
	?>









<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">

        <link rel="stylesheet" href="assets/css/swiper-bundle.min.css">

        <link rel="stylesheet" href="assets/css/styles.css">

		<link rel="shortcut icon" href="https://i.pinimg.com/736x/0d/cf/b5/0dcfb548989afdf22afff75e2a46a508.jpg" id="imm" type=" svg+xml">
	<title>SELFCAREBOOSTER</title>
    </head>

	<style>
		:root {
  --header-height: 3.5rem;

  /*========== Colors ==========*/
  --hue: 14;
  --first-color: hsl(var(--hue), 91%, 54%);
  --first-color-alt: hsl(var(--hue), 91%, 50%);
  --title-color: hsl(var(--hue), 4%, 100%);
  --text-color: hsl(var(--hue), 4%, 85%);
  --text-color-light: hsl(var(--hue), 4%, 55%);

  /* gradient*/
  --body-color: linear-gradient(90deg, hsl(197, 83%, 51%) 0%, hsl(211, 86%, 62%) 100%);
  --container-color: linear-gradient(136deg, hsl(191, 100%, 50%) 0%, hsl(192, 100%, 52%) 100%);
  

		}
	</style>
    <body>
        <!--==================== HEADER ====================-->
    

            <section class="section discount">
                <div class="discount__container container grid">
                    <div class="discount__data">
                        <h2 class="discount__title">Congratulations!</h2>
                        <h2 class="discount__title">You have successfully completed the test</h2>
                        <p class="discount__title">Total points: </p><?php if (isset($_SESSION['score'])) {
                            echo $_SESSION['score']; 
                            }; ?> 
							<br>
							<br>

<a href="question.php?n=1" class="button">Start Again</a>

                    <a href="home.php" class="button">Go Home</a>
                        
                    </div>


                    
                   
                         
                    
                   
                       
                 

                    <!-- <img src="assets/img/discount-img.png" alt="" class="discount__img"> -->
                </div>
            </section>

        
        
        <!--=============== SCROLL REVEAL ===============-->
        <script src="assets/js/scrollreveal.min.js"></script>

        <!--=============== SWIPER JS ===============-->
        <script src="assets/js/swiper-bundle.min.js"></script>
        
        <!--=============== MAIN JS ===============-->
        <script src="assets/js/main.js"></script>
    </body>
</html>














<!-- <html>
	<head>
		<title>SELFCAREBOOSTER/result</title>
		<link rel="shortcut icon" href="https://i.pinimg.com/736x/0d/cf/b5/0dcfb548989afdf22afff75e2a46a508.jpg" id="imm" type=" svg+xml">
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>

	<body>
		<header>
			<div class="container">
				<h1>Quiz to check mental health status</h1>
			</div>
		</header>

		<main>
			<div class= "container">
			<h2>Congratulations!</h2> 
				<p>You have successfully completed the test</p>
				<p>Total points: <?php if (isset($_SESSION['score'])) {
echo $_SESSION['score']; 
}; ?> </p>
		<a href="question.php?n=1" class="start">Start Again</a>
		<a href="home.php" class="start">Go Home</a>
		</div>
		</main>
		</body>
		</html> -->

		<?php 
		$score = $_SESSION['score'];
		$email = $_SESSION['email'];
		$query = "UPDATE users SET score = '$score' WHERE email = '$email'";
		$run = mysqli_query($conn , $query) or die(mysqli_error($conn));
 		?>


<?php unset($_SESSION['score']); ?>
<?php unset($_SESSION['time_up']); ?>
<?php unset($_SESSION['start_time']); ?>
<?php }
else {
	header("location: home.php");
}
?>

