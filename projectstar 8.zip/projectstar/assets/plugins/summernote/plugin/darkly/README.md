This folder contains the Darkly for Summernote Lite Edition.

summernote-lite-darkly.css uses the Summernote supplied Icons
![summernote-lite-darkly](summernote-lite-darkly.png)

summernote-lite-darkly-libre.css uses the DiemenDesign LibreICONS SVG black&white Icons
![summernote-lite-darkly-libre](summernote-lite-darkly-libre.png)

summernote-lite-darkly-libre-col.css uses the DiemenDesign LibreICONS SVG Colour Icons
![summernote-lite-darkly-libre-col](summernote-lite-darkly-libre-col.png)
